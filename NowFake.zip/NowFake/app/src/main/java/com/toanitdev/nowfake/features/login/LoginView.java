package com.toanitdev.nowfake.features.login;


import com.toanitdev.nowfake.models.Response.LoginResponse;

public interface LoginView{

    void renderLogin(LoginResponse value);
}
