<?php
  
include_once '../../config.php';
include_once '../../entity/Customer.php';
 
$database = new Database();
$db = $database->getConnection();
 
$customer = new Customer($db);

$customer->idCustomer = isset($_POST['idCustomer']) ? $_POST['idCustomer'] : die();

$stmt = $customer->getCustomer();

if($stmt->rowCount() > 0){
    
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $cus_array=array(
            "id_customer"=>$row['idCustomer'],
            "email"=>$row['email'],
            "name_customer"=>$row['nameCustomer'],
            "phone_customer"=>$row['phoneCustomer'],
            "date_of_birth"=>$row['dateOfBirth']
        ); 
  
}else{
    $cus_array=array(
        "tinhTrang" => false,
        "loiNhan" => "Invalid Username or Password!",
    );
}
print_r(json_encode($cus_array));
?>