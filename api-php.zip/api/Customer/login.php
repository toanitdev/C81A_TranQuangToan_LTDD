<?php
  
  // include database and object files
include_once '../config.php';
include_once '../entity/Customer.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare user object
$customer = new Customer($db);
// set ID property of user to be edited

$customer->userName = isset($_POST['tk']) ? $_POST['tk'] : die();
$customer->passWord = isset($_POST['mk']) ? $_POST['mk'] : die();
// read the details of user to be edited

$stmt = $customer->dangNhap();
if($stmt->rowCount() > 0){
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array
    $customer_arr=array(
        "tinhTrang" => true,
        "loiNhan" => "Successfully Login!",
        "idCustomer" => $row['idCustomer'],
        "userName" => $row['userName']
    );
}
else{
    $customer_arr=array(
        "tinhTrang" => false,
        "loiNhan" => "Invalid Username or Password!",
    );
}
// make it json format
print_r(json_encode($customer_arr));

?>