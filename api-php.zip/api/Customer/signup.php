<?php
  
include_once '../config.php';
include_once '../entity/Customer.php';
 
$database = new Database();
$db = $database->getConnection();
 
$customer = new Customer($db);

$customer->nameCustomer = isset($_GET['name']) ? $_GET['name'] : die();
$customer->userName = isset($_GET['tk']) ? $_GET['tk'] : die();
$customer->passWord = isset($_GET['mk']) ? $_GET['mk'] : die();
$customer->phoneCustomer = isset($_GET['phoneCustomer']) ? $_GET['phoneCustomer'] : die();
$customer->email = isset($_GET['email']) ? $_GET['email'] : die();
$customer->dateOfBirth = isset($_GET['dateofbirth']) ? $_GET['dateofbirth'] : die();



$stmt1 = $customer->isTonTaiTaiKhoan();
if($stmt1->rowCount() > 0){
    $messenge = array("messenge"=>"Tài khoản tồn tại",
                        "state"=>"false");
}else{
    $stmt2 = $customer->dangKy();
    if($stmt2->rowCount() > 0){
    $messenge = array(
                        "state"=>"true");
    }else{
        
    $messenge = array("messenge"=>"Lỗi đăng ký",
            "state"=>"false");
    }
}
    print_r(json_encode($messenge));

?>