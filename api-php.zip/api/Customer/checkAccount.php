<?php
  
  // include database and object files
include_once '../config.php';
include_once '../entity/Customer.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare user object
$customer = new Customer($db);
// set ID property of user to be edited

$customer->userName = isset($_GET['tk']) ? $_GET['tk'] : die();
// read the details of user to be edited

$stmt = $customer->isTonTaiTaiKhoan();
if($stmt->rowCount() > 0){
    $customer_arr=array(
        "isExist" => true
       
    );
}
else{
   $customer_arr=array(
        "isExist" => false
       
    );
}
print_r(json_encode($customer_arr));

?>