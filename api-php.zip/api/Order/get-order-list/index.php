<?php
  
include_once '../../config.php';
include_once '../../entity/Order.php';
 
$database = new Database();
$db = $database->getConnection();
 
$order = new Order($db);

$order->idCustomer = isset($_GET['idOrder']) ? $_GET['idOrder'] : die();

$stmt = $order->getAllOrder();

if($stmt->rowCount() > 0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT)) {
        $dish_array[]=array(
            "id_order"=>$row['idOrder'],
            "total"=>$row['total'],
            "shipping_address"=>$row['shippingAddress'],
            "number_phone"=>$row['numberPhone'],
            "order_time"=>$row['orderTime'],
            "id_customer"=>$row['idCustomer']            
        );
    }
}
else{
    $dish_array=array(
        "tinhTrang" => false,
        "loiNhan" => "Invalid Username or Password!",
    );
}
print_r(json_encode($dish_array));
?>