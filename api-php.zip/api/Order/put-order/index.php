<?php
  
include_once '../../config.php';
include_once '../../entity/Order.php';
include_once '../../entity/Cart.php';
include_once '../../entity/ItemOrder.php';
include_once '../../entity/Dish.php';
 
$database = new Database();
$db = $database->getConnection();
$db1 = $database->getConnection();
$db2 = $database->getConnection();
 
$order = new Order($db);
$cart = new Cart($db1);
$dish = new Dish($db2);
$itemOrder = new ItemOrder($db2);
$order->idCustomer = isset($_POST['idCustomer']) ? $_POST['idCustomer'] : die();
$order->numberPhone = isset($_POST['numberPhone']) ? $_POST['numberPhone'] : die();
$order->shippingAddress = isset($_POST['shippingAddress']) ? $_POST['shippingAddress'] : die();
$order->total = isset($_POST['total']) ? $_POST['total'] : die();
$cart->idCustomer = $order->idCustomer;

$db->beginTransaction();
$stmt = $order->putOrder();
$stmt2 = $cart->getCartByCustomer();
if($stmt->rowCount() > 0){
    $lastId = $db->lastInsertId();
    while ($row = $stmt2->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT)) {
        $itemOrder->idDish = $row['idDish'];
        $dish->idDish = $row['idDish'];
        $stmt3 = $dish->getListDishByIdDish();
        $row2 = $stmt3->fetch(PDO::FETCH_ASSOC);
        $itemOrder->discountPrice = $row2['discountPrice'];
        $itemOrder->idOrder = $lastId;   
        $itemOrder->number =$row['stock'];                
        $stmt3 = $itemOrder->putItemOrder();
    }
    $stmt2 = $cart->deleteCusCart();
    
    $result = array(
        "state"=>true,
        "messenge"=>"Đặt hàng thành công",
        "id_order"=>$lastId
    );
    print_r(json_encode($result));
 
}else{
    $result = array(
        "state"=>false,
        "messenge"=>"Đặt hàng thất bại",
        "id_order"=>""
    );
    print_r(json_encode($result));
}
$db->commit();
?>