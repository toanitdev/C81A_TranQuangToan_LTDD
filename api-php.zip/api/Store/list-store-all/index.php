<?php
  
include_once '../../config.php';
include_once '../../entity/Store.php';
$database = new Database();
$db = $database->getConnection();

$dish = new Store($db);

$stmt = $dish->getListStoreAll();

if($stmt->rowCount() > 0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT)) {
        $dish_array[]=array(
            "id_store"=>$row['idStore'],
            "name_store"=>$row['nameStore'],
            "address_store"=>$row['addressStore'],
            "number_phone_store"=>$row['numberPhoneStore'],
            "position_address_store"=>$row['positionAddressStore'],
            "description_store"=>$row['descriptionStore']
        );
    }
    
    $listArray=array("list_store"=>$dish_array);
}
else{
    $listArray=array(
        "tinhTrang" => false,
        "loiNhan" => "Invalid Username or Password!",
    );
}
print_r(json_encode($listArray));

?>