<?php

class Cart{
    private $conn;
    private $table_name ="cart";


    public $idItemCart;
    public $stock;
    public $idDish;
    public $idCustomer;

    public function __construct($db)
    {
        $this->conn = $db;        
    }    

    function getAllCart($idCustomer){
        $query =    "SELECT *
                    FROM `cart`
                    WHERE idCustomer = '".$idCustomer."'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }   
    function putItem(){
        if($this->isExistDish()->rowCount()>0){
           // $query = "UPDATE `cart` SET `stock` = `stock`+1 WHERE `cart`.`idItemCart` = '".$this->idCustomer."';";
             $query = "UPDATE `cart` SET `stock` = `stock`+1 
                        WHERE `cart`.`idCustomer` = '".$this->idCustomer."'
                                AND `cart`.`idDish` = '".$this->idDish."';";

        }else{
            $query = "INSERT INTO `cart`(`idCustomer`, `idDish`, `stock`) 
            VALUES ('".$this->idCustomer."',
            '".$this->idDish."',
            '1')";
        }

        

        $stmt  = $this->conn->prepare($query);
        
        $stmt->execute();    
        return $stmt;
    }

    function deleteCusCart(){
       
            $query = "DELETE FROM `cart` WHERE idCustomer = '".$this->idCustomer."'";
        $stmt  = $this->conn->prepare($query);
        
        $stmt->execute();    
        return $stmt;
    }
    
    function getCartByCustomer(){
        $query =    "SELECT *
                    FROM `cart`, `dish`
                    WHERE idCustomer = '".$this->idCustomer."' AND `cart`.idDish = `dish`.idDish ";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }
    function countItem(){
        $query =    "SELECT count(*) as counts
                    FROM `cart`
                    WHERE idCustomer = '".$this->idCustomer."'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }
 
    function isExistDish(){
        $query =    "SELECT *
                    FROM `cart`
                    WHERE idDish = '".$this->idDish."' AND idCustomer = '".$this->idCustomer."'";
        $stmt  = $this->conn->prepare($query);
        $stmt->execute();    
        return $stmt;
    }
}

?>