<?php

class Dish{
    private $conn;
    private $table_name ="dish";


    public $idDish;
    public $nameDish;
    public $priceDish;
    public $discounPrice;
    public $desciptionDish;
    public $shortDescription;
    public $hotDeal;
    public $linkImage;
    public $idStore;
    public $idType;

    public function __construct($db)
    {
        $this->conn = $db;        
    }    

    function getListDishAll(){
        $query =    "SELECT * FROM `dish`";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }
    function getListDishAllByPage($page){
        
    }
    function getListDishByType($idType){
        $query =    "SELECT * FROM `dish` WHERE `idType` =".$idType."";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;       
    }
    function getListDishByStore($idStore){
        $query =    "SELECT * FROM `dish` WHERE `idStore` =".$idStore."";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;       
    }
    function getListDishByIdDish(){
        $query =    "SELECT * FROM `dish` WHERE `idDish` =".$this->idDish."";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;       
    }
    function getListDishHotDeal(){
        $query =    "SELECT * FROM `dish` WHERE `hotDeal`=1";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;       
    }
    function getDishByName($name){
        $query =    "SELECT * FROM `dish` WHERE `nameDish` like '%".$name."%'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;       
    }

    function dangKy(){
        

    }

    function isTonTaiTaiKhoan(){
       

    }


}

?>