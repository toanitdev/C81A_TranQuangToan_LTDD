<?php

class Store{
    private $conn;
    private $table_name ="store";


    public $idStore;
    public $nameStore;
    public $addressStore;
    public $numberPhoneStore;
    public $positionAddressStore;
    public $descriptionStore;
    public $imageStore;

    public function __construct($db)
    {
        $this->conn = $db;        
    }    

    function getListStoreAll(){
        $query =    "SELECT * FROM `store`";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }
}

?>