<?php

class Order{
    private $conn;
    private $table_name ="orders";


    public $idOrder;
    public $total;
    public $shippingAddress;
    public $numberPhone;
    public $idCustomer;

    public function __construct($db)
    {
        $this->conn = $db;        
    }    

    function getAllOrder(){
        $query =    "SELECT *
                    FROM `orders`
                    WHERE idCustomer = '".$this->idCustomer."'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }   
    function putOrder(){
            $query = "INSERT INTO `orders`(`total`,`idCustomer`,`shippingAddress`,`numberPhone`) 
            VALUES ('".$this->total."','".$this->idCustomer."','".$this->shippingAddress."','".$this->numberPhone."')";

        

        $stmt  = $this->conn->prepare($query);
        
        $stmt->execute();    
        return $stmt;
    }
  
}

?>