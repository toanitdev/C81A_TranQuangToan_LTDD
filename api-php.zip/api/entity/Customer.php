<?php

class Customer{
    private $conn;
    private $table_name ="customer";


    public $idCustomer;
    public $nameCustomer;
    public $userName;
    public $passWord;
    public $deliveryAddress;
    public $phoneCustomer;
    public $positionDeliveryAddress;
    public $email;
    public $dateOfBirth;
    public function __construct($db)
    {
        $this->conn = $db;        
    }    

    function dangNhap(){
        $query =    "SELECT *
                    FROM `customer`
                    WHERE userName = '".$this->userName."' AND passWord = '".$this->passWord."'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }

    function dangKy(){
         $query =      "INSERT INTO `customer`(`nameCustomer`, `email`, `phoneCustomer`, `dateOfBirth`, `userName`, `passWord`) 
         VALUES ('".$this->nameCustomer."',
         '".$this->email."',
         '".$this->phoneCustomer."',
         '".$this->dateOfBirth."',
         '".$this->userName."',
         '".$this->passWord."')";

        $stmt  = $this->conn->prepare($query);
        
        $stmt->execute();    
        return $stmt;

    }

    function isTonTaiTaiKhoan(){
        $query =    "SELECT *
                    FROM `customer`
                    WHERE userName = '".$this->userName."'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;

    }
    function getCustomer(){
        $query =    "SELECT *
                    FROM `customer`
                    WHERE idCustomer = '".$this->idCustomer."'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;

    }


}

?>