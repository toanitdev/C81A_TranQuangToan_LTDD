<?php

class ItemOrder{
    private $conn;
    private $table_name ="itemOrders";


    public $idItemOrder;
    public $originPrice;
    public $discountPrice;
    public $number;
    public $name;
    public $idDish;
    public $idOrder;

    public function __construct($db)
    {
        $this->conn = $db;        
    }    

    function getOrderDetail(){
        $query =    "SELECT *
                    FROM `itemOrders`
                    WHERE idOrder = '".$this->idOrder."'";

        $stmt  = $this->conn->prepare($query);

        $stmt->execute();    
        return $stmt;
    }   
    function putItemOrder(){
            $query = "INSERT INTO `itemOrders` (`idItemOrder`,
                                                 `originPrice`,
                                                  `discountPrice`,
                                                   `number`,
                                                    `name`,
                                                     `idDish`,
                                                      `idOrder`) 
                                        VALUES (NULL,
                                                 '0',
                                                  '".$this->discountPrice."',
                                                   '".$this->number."',
                                                    '0',
                                                     '".$this->idDish."',
                                                      '".$this->idOrder."');";

        

        $stmt  = $this->conn->prepare($query);
        
        $stmt->execute();    
        return $stmt;
    }
  
}

?>