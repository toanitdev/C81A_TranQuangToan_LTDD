<?php
  
include_once '../../config.php';
include_once '../../entity/Cart.php';
 
$database = new Database();
$db = $database->getConnection();
 
$cart = new Cart($db);

$cart->idDish = isset($_POST['idDish']) ? $_POST['idDish'] : die();
$cart->idCustomer = isset($_POST['idCustomer']) ? $_POST['idCustomer'] : die();

$stmt = $cart->putItem();
if($stmt->rowCount() > 0){
    echo "true";
 
}else{
    echo "false"; 
}
?>