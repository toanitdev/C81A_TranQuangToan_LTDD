<?php
  
include_once '../../config.php';
include_once '../../entity/Cart.php';
 
$database = new Database();
$db = $database->getConnection();
 
$cart = new Cart($db);

$cart->idCustomer = isset($_GET['idCustomer']) ? $_GET['idCustomer'] : die();

$stmt = $cart->countItem();

if($stmt->rowCount() > 0){
    $row = $stmt->fetch(PDO::FETCH_ASSOC)['counts'];
}
else{
    $row = "0";
}
print_r($row);
?>