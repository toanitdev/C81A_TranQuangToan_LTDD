<?php
  
include_once '../../config.php';
include_once '../../entity/ItemOrder.php';
 
$database = new Database();
$db = $database->getConnection();
 
$itemOrder = new ItemOrder($db);

$itemOrder->idOrder = isset($_GET['idOrder']) ? $_GET['idOrder'] : die();

$stmt = $itemOrder->getOrderDetail();

if($stmt->rowCount() > 0){
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT)) {
        $dish_array[]=array(
            "id_order"=>$row['idItemOrder'],
            "origin_price"=>$row['originPrice'],
            "discount_price"=>$row['discountPrice'],
            "number"=>$row['number'],
            "name"=>$row['name'],
            "id_order"=>$row['idOrder']            
        );
    }
}
else{
    $dish_array=array(
        "tinhTrang" => false,
        "loiNhan" => "Invalid Username or Password!",
    );
}
print_r(json_encode($dish_array));
?>