<?php
  
include_once '../../config.php';
include_once '../../entity/Dish.php';
$database = new Database();
$db = $database->getConnection();

$dish = new Dish($db);

if(isset( $_GET['name'])){
    $name = $_GET['name'];
}else{
    die();
}

$stmt = $dish->getDishByName($name);

if($stmt->rowCount() > 0){
    //$row = $stmt->fetch(PDO::FETCH_ASSOC);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT)) {
        $dish_array[]=array(
            "id_dish"=>$row['idDish'],
            "name_dish"=>$row['nameDish'],
            "price_dish"=>$row['priceDish'],
            "discount_price"=>$row['discountPrice'],
            "desciption_dish"=>$row['desciptionDish'],
            "short_desciption"=>$row['shortDesciption'],
            "hot_deal" => $row['hotDeal'],
            "link_image"=>$row['linkImage'],
            "id_store"=>$row['idstore'],
            "id_type"=>$row['idType']
        );
    }
    
  
}
else{
    $dish_array=array(
        "tinhTrang" => false,
        "loiNhan" => "Invalid Username or Password!",
    );
}
print_r(json_encode($dish_array));

?>